function hog()
img=imread('caltech_web_crop_00038.jpg');
hog = vl_hog(im2single(img), 6);
imhog = vl_hog('render', hog,'verbose');
figure(1);
imshow(imhog);

